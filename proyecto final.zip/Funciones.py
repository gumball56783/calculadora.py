import sys
from openpyxl import Workbook
import openpyxl
import serial,time 
import matplotlib.pyplot as plt
from openpyxl import Workbook
import sys
import os


def leerPulsosArduino():
    valores = []
    tiempos = []
    state = True
    arduino = None

    try:
        arduino = serial.Serial("COM3",9600)
        time.sleep(4)
        arduino.write(b"1")
        for i in range(1000):
            lectura = arduino.readline()
            lectura = lectura.decode()
            lectura = lectura.replace("\r\n",)
            lectura = lectura.split(",")
            valor = float(lectura[0])
            tiempo = float(lectura[1])
            valores.append(valor)
            tiempos.append(tiempo)
    except:
        state = False
    finally:
        if arduino is not None:
            arduino.close()
        return state, valores, tiempos

            


def graficarDatos(tiempos , valores):
    plt.plot(tiempos,valores)
    plt.show()

def crearExcel(direccion,tiempos,pulsos,encabezados):
    try:
        wb = Workbook()

        ws.title = "pulsos"

        ws.cell(row=1, column=1, value=encabezados[0])
        ws.cell(row=1, column=2, value=encabezados[1])

        for i in range(len(tiempos)):
            ws.cell(row=i+2, column=1 value=tiempos[i])
            ws.cell(row=i+2, column=2 value=tiempos[i])
        wb.save(direccion)
        return True
    except:
        return False

def resource_path(relative_path):
    if hasattr(sys,'_METIPASS ' ):
        return os.path.join(sys._METIPASS,relative_path)
    return os.path.join(os.path.abspath("."),relative_path)
