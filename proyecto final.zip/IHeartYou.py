from email import message
from email.errors import InvalidHeaderDefect
import resource
import tkinter as tk 
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image
from PIL import ImageTk
from Funciones import *

pulsos = []
tiempos = []


def leerpulsos():
    global pulsos, tiempos
    state,pulsos,tiempos = leerPulsosArduino()
    if state:
        messagebox.showinfo(message="Datos leidos correctamente",title="Lectura exitosa")
        graficarDatos(tiempos,pulsos)
    else:
        messagebox.showerror(message="Fallo la conexion con Arduino!",title="Error de conexion")



def guardar():
    if len(pulsos) != 0 and len(tiempos) !=0:
        direccion = filedialog.askdirectory() + "/Pulsos.xlsx"
        state = crearExcel(direccion,tiempos,pulsos,["tiempo","pulsos"])
        if state:
            messagebox.showinfo(message="Archivo creado correctamente.",title="Guardado exitoso")
        else:
            messagebox.showerror(message="Fallo en la creacion de Archivo!",title="Error de archivo")
    else:
        messagebox.showerror(message="No se han regristrado lecturas.",title="Error de ejecucion.")

fd = "images/logo_corazon.png"
fd = resource_path("logo_corazon.png")

background_color = "#141414"
button_color1 = "#3800B3"
button_color2 = "#008786"

ventana = tk.Tk()
ventana.title("I Heart You!")
logo = tk.PhotoImage(file=fd)
ventana.iconphoto(False,logo)
ventana.configure(bg=background_color)

space_frame = tk.Frame(ventana)
space_frame.pack(ipadx=40)
space_frame.configure(bg=background_color)

load = Image.open(fd)
load = load.resize((200,200),Image.ANTIALIAS)
render = ImageTk.PhotoImage(load)

IHeart_logo = tk.Label(space_frame, image = render , bg=background_color)
IHeart_logo.pack()

frame1 = tk.Frame(ventana)
frame1.pack(ipad=40,ipady=20)
frame1.configure(bg=background_color)

etiqueta1 = tk.Label(frame1,text="Presiona el boton para tomar el pulso.",bg=background_color,front=14,fg="white")
etiqueta1.pack()

frame2 = tk.Frame(ventana)
frame2.pack(ipady=40,ipad=10)
frame2.configure(bg=background_color)

boton_lectura = tk.Button(frame2,text="Tomar pulso",bg=button_color1,front="Helvetica 14 bold", fg="white",command=leerpulsos)
boton_lectura.pack()

frame3 = tk.Frame(ventana)
frame3.pack(ipady=40,ipad=10)
frame3.configure(bg=background_color)

etiqueta2 = tk.Label(frame3,text="Escoge la carpeta para guardar.",bg=background_color,front=14,fg="white")
etiqueta2.pack()

frame4 = tk.Frame(ventana)
frame4.pack(ipady=40,ipad=10)
frame4.configure(bg=background_color)

boton_guardar = tk.Button(frame4,text="Tomar pulso",bg=button_color1,front="Helvetica 14 bold", fg="white",command=guardar)
boton_guardar.pack()

ventana.mainloop()
