archivo = open("archivo_prueba.txt","r")

lectura = archivo.readlines()

archivo.close()

lectura.append("elemento4")

archivo = open("archivo_prueba.txt","r")

archivo.writelines()

archivo.close()


