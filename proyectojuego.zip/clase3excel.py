from openpyxl import Workbook
from openpyxl import load_workbook

#crear excel
def createExcel():
    wb = Workbook()
    ws = wb.active
    ws.title = "Hoja1"
    ws["A1"] = "Hola mundo"

    ws2 = wb.create_sheet("Hoja2")
    ws2 ["A1"] = "Bienvenido a la segunda hoja"

    ws3 = wb.create_sheet("Hoja3")
    ws3 ["A1"] = "Bienvenido a la tercer hoja"

    
    #wb.save("./ClasePython.xlsx") 
    wb.save("ClasePython.xlsx")

def openExcel():
    wb = load_workbook("ClasePython.xlsx")

    print(wb.sheetnames)#leer el nombre de las hojas

    ws = wb["Hoja1"]
    valor = ws.cell(1,1).value
    print(valor)

    wb.save("ClasePython.xlsx")


createExcel()

openExcel()

