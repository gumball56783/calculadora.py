archivo = open("archivo_prueba.txt","r")

lectura = archivo.readlines()

archivo.close()

print(lectura)

cadena_texto = ""

for linea in lectura:
    cadena_texto = cadena_texto + linea

    print(cadena_texto)
     