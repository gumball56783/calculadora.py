from funcionesarchivos import guardarGanadores
from personaje import personaje
from random import randint
def controljuego(luchador1,luchador2):
    turno = 0

    while not luchador1.morir() and not luchador2.morir():
        print("vida ",luchador1.nombre,":",luchador1.vida)
        print("vida ",luchador2.nombre,":",luchador2.vida)

        if turno%2 == 0:
            print("turno jugador 1")
            input("presione una tecla para atacar")
            if randint(0,100) > 35:
                ataque_oponente = luchador1.atacar()
                luchador2.defender(ataque_oponente)
            else:
                print(luchador2.nombre,"esquivo el ataque")
        else:
            print("turno jugador 2")
            input("presione una tecla para atacar")
            if randint(0,100) > 35:
                ataque_oponente = luchador2.atacar()
                luchador1.defender(ataque_oponente)
            else:
                print(luchador1.nombre,"esquivo el ataque")
        turno += 1        
    if luchador1.morir():
        guardarGanadores(luchador2.nombre)
    else:
        guardarGanadores(luchador1.nombre)
        

       