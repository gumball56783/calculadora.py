from personaje import personaje
from openpyxl import workbook
from openpyxl import load_workbook

def obtenerluchadores(numero_luchadores):
    luchadores = []

    workbook = load_workbook("Luchadores.txt")
    worksheet = workbook.active

    for i in range(numero_luchadores):
        nombre = worksheet.cell(i+1, 1).value
        ataque = worksheet.cell(i+1, 2).value
        defensa = worksheet.cell(i+1, 3).value
        vida = worksheet.cell(i+1, 4).value
        luchador = personaje(nombre,ataque,defensa,vida)
        luchadores.append(luchador)
    return luchadores

def guardarGanadores(ganador):
    archivo = open("ganadores.txt","r")
    contenido = archivo.readlines()
    archivo.close()
    contenido.append("\t\t"+ganador+"\n")

    archivo = open("ganadores.txt", "w")
    archivo.writelines(contenido)
    archivo.close()
    

    



