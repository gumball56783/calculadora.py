from personaje import personaje
from controljuego import controljuego
from funcionesarchivos import obtenerluchadores

def main():

    luchadores = obtenerluchadores(4)

    for i in range(len(luchadores)):
        print(i+1,")",luchadores[i].nombre)
    
    
    while True:
        try:
            seleccion1 = int(input("segundo personaje:"))
            if seleccion1 <= 0 or seleccion1 > len(luchadores):
                print ("no existe ese luchador,intenta otra vez")
            else:
                break
        except ValueError:
            print("caracter no reconocido,intenta otra vez")



    while True:
        try:
            seleccion2 = int(input("primer personaje:"))
            if seleccion2 <= 0 or seleccion2 > len(luchadores):
                print ("no existe ese luchador,intenta otra vez")
            else:
                break
        except ValueError:
            print("caracter no reconocido,intenta otra vez")

    luchador1 = luchadores[seleccion1-1]
    luchador2 = luchadores[seleccion1-1]

    controljuego(luchador1,luchador2)
    print("partida finalizada")
  
main()
    