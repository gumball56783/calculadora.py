class personaje():

    def __init__(self, nombre, ataque, defensa, vida):
        self.nombre = nombre 
        self.ataque = ataque
        self.defensa = defensa
        self.vida = vida
    
    def atacar(self):
        print(self.nombre, "esta atacando")
        return self.ataque

    def defender(self, ataque_oponente):
        print (self.nombre, "esta defendiendose")
        damage = (ataque_oponente/self.defensa) * 100
        self.vida -= damage

    def morir(self):
        if self.vida <= 0:
            print(self.nombre, "murio")
            return True
        else:
            return False